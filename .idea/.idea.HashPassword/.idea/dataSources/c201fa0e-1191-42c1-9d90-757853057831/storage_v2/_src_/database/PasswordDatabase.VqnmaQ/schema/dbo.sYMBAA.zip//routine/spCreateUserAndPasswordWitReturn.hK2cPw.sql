create procedure dbo.spCreateUserAndPasswordWitReturn(@Password nvarchar(max),
                                                      @Salt nvarchar(max),
                                                      @FirstName nvarchar(200),
                                                      @LastName nvarchar(100),
                                                      @id int OUTPUT) as
BEGIN
    SET NOCOUNT ON;
    insert into Users (Password, Salt, FirstName, LastName) values (@Password, @Salt, @FirstName, @LastName);

    select @id = id
    from Users
    where FirstName = @FirstName;
END;
go

